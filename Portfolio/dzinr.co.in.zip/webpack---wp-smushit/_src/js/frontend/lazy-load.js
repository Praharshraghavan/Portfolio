import lazySizes from 'lazysizes';

lazySizes.init();